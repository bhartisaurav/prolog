# PPs
Codes Related To Prolog Language
