mul(N1,N2,Result):-
	Result is N1*N2.
