/* Write a prolog program to calculate the sum of two numbers.*/
sum(X,Y,S):-
	S is X+Y.
