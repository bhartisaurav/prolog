/* Write a Prolog program to implement append for two lists. */
apptwolist(L1,L2,F):-
	append(L1,L2,F).
